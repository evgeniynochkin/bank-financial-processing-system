package ru.sbp.bankfinancialprocessingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * @author Konstantin Filin
 */
@SpringBootApplication
public class BankFinancialProcessingSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(BankFinancialProcessingSystemApplication.class, args);
	}
}